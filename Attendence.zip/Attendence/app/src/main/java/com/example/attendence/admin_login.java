package com.example.attendence;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class admin_login extends AppCompatActivity {
    public Button login;
    public EditText user, pass;
    private FirebaseAuth mAuth;
    public FirebaseDatabase database;
    public DatabaseReference reference;
    public String Id;

    public String email, password;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        user = findViewById(R.id.e1);
        pass = findViewById(R.id.e2);




        login = findViewById(R.id.but1);
        database = FirebaseDatabase.getInstance();

        mAuth = FirebaseAuth.getInstance();

        String host = mAuth.getCurrentUser().getUid();
        if(host != null){

            reference =database.getReference().child("Admins").child(host);
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.getValue() == null){
                        Toast.makeText(admin_login.this, "U are Not Authorize", Toast.LENGTH_SHORT).show();
                        mAuth.signOut();
                    }else{
                        startActivity(new Intent(admin_login.this, admin_dashboard.class));
                    }


                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(admin_login.this, "database error try again later", Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(admin_login.this, "Please Input the Creditnals", Toast.LENGTH_SHORT).show();
        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                email = user.getText().toString().trim();
                password = pass.getText().toString().trim();

                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Id = mAuth.getCurrentUser().getUid();
                        reference =database.getReference().child("Admins").child(Id);
                        reference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                               if(dataSnapshot.getValue() == null){
                                   Toast.makeText(admin_login.this, "U are Not Authorize", Toast.LENGTH_SHORT).show();
                                   mAuth.signOut();
                               }else{
                                   startActivity(new Intent(admin_login.this, admin_dashboard.class));
                               }


                            }


                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(admin_login.this, "database error try again later", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });



                }

        });
    }
}
