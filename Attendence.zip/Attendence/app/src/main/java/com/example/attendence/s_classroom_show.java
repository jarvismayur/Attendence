package com.example.attendence;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class s_classroom_show extends AppCompatActivity {
    public FirebaseDatabase database;
    public DatabaseReference myRef;
    public FirebaseAuth mAuth;
    public String id;
    public ListView table1, table2, table3;
    public Button dash, add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_classroom_show);
        table1 = findViewById(R.id.list_item);
        table2 = findViewById(R.id.list_item2);
        table3 = findViewById(R.id.list_item3);
        dash = findViewById(R.id.but_2);
        add = findViewById(R.id.but1);

        final ArrayList<String> arrayList1 = new ArrayList<>();
        final ArrayList<String> arrayList2 = new ArrayList<>();
        final ArrayList<String> arrayList3 = new ArrayList<>();

        id = mAuth.getCurrentUser().getUid();
        String pass = "Staff/"+ id +"/classroom";
        String underpass = pass + "/" + "branch";
        Toast.makeText(s_classroom_show.this, underpass, Toast.LENGTH_SHORT).show();
        myRef = database.getReference().child(underpass);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String data = dataSnapshot.getValue(String.class);
                Toast.makeText(s_classroom_show.this, data, Toast.LENGTH_LONG).show();
                arrayList1.add(data);
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(s_classroom_show.this, android.R.layout.simple_list_item_1, arrayList1);
                table1.setAdapter(arrayAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        underpass = pass + "/semister";
        myRef = database.getReference().child(underpass);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String data = dataSnapshot.getValue(String.class);
                arrayList2.add(data);
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(s_classroom_show.this, android.R.layout.simple_list_item_1, arrayList2);
                table2.setAdapter(arrayAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(s_classroom_show.this, databaseError.toString(), Toast.LENGTH_SHORT).show();

            }
        });

        underpass = pass + "/subject";
        myRef = database.getReference().child(underpass);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String data = dataSnapshot.getValue(String.class);
                arrayList3.add(data);
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(s_classroom_show.this, android.R.layout.simple_list_item_1, arrayList3);
                table3.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(s_classroom_show.this, staff_dashboard.class));
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(s_classroom_show.this, s_classroom_add.class));
            }
        });
    }


}
