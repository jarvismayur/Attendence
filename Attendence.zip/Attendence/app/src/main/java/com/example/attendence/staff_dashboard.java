package com.example.attendence;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class staff_dashboard extends AppCompatActivity {
    public Button classroom, students, attendence, logout;
    public FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_dashboard);
        classroom = findViewById(R.id.but_class);
        students = findViewById(R.id.but_students);
        attendence = findViewById(R.id.but_attendence);
        logout = findViewById(R.id.but_logout);

        classroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(staff_dashboard.this, s_classroom.class));
            }
        });
        students.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(staff_dashboard.this, s_students.class));
            }
        });
        attendence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(staff_dashboard.this, s_attendence.class));
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth = FirebaseAuth.getInstance();
                mAuth.signOut();
                startActivity(new Intent(staff_dashboard.this, MainActivity.class));
            }
        });

    }
}
