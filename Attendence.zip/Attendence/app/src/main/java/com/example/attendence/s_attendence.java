package com.example.attendence;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class s_attendence extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_attendence);
    }
}
