package com.example.attendence;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class add_staff_admin extends AppCompatActivity {
    public TextView t1;
    public EditText fname, mob;
    public Button addUser;
    private FirebaseAuth mAuth;
    public FirebaseDatabase database;
    public DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_staff_admin);
        t1 = findViewById(R.id.t1);
        fname = findViewById(R.id.e1);
        mob = findViewById(R.id.e2);
        addUser = findViewById(R.id.but1);

        mAuth =FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();


        String data = getIntent().getStringExtra("Data");
        data = data.substring(0,7);
        t1.setText(data);

        addUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = fname.getText().toString().trim();
                String phn = mob.getText().toString().trim();
                String id = mAuth.getCurrentUser().getUid();
                String token = t1.getText().toString().trim();
                reference = database.getReference().child("Token").child(token);
                reference.child("name").setValue(name);
                reference.child("phn").setValue(phn);
                reference =database.getReference().child(id).child("Token").child(token);
                reference.child("name").setValue(name);
                reference.child("phn").setValue(phn);
            }
        });
    }
}
