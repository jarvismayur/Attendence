package com.example.attendence;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.UUID;

import javax.xml.validation.Validator;

public class admin_dashboard extends AppCompatActivity {
    public Button add_staff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        add_staff = findViewById(R.id.but1);

        add_staff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UUID uuid = UUID.randomUUID();
                String Data = uuid.toString();
                Intent intent = new Intent(admin_dashboard.this, add_staff_admin.class);
                intent.putExtra("Data", Data);
                startActivity(intent);
            }
        });
    }
}
