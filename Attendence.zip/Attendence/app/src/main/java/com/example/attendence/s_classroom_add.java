package com.example.attendence;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class s_classroom_add extends AppCompatActivity {
    public EditText branch, semister, subject;
    public Button submit, show, dash;
    public FirebaseAuth mAuth;
    public DatabaseReference reference;
    public FirebaseDatabase database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_classroom_add);
        branch = findViewById(R.id.e1);
        semister = findViewById(R.id.e2);
        subject = findViewById(R.id.e3);
        submit  = findViewById(R.id.but_1);
        show  = findViewById(R.id.but_2);
        dash  = findViewById(R.id.but_3);
        mAuth =  FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = mAuth.getCurrentUser().getUid();
                reference = database.getReference().child("Staff").child(id).child("classroom");
                reference.child("branch").setValue(branch.getText().toString().trim());
                reference.child("semister").setValue(semister.getText().toString().trim());
                reference.child("subject").setValue(subject.getText().toString().trim());
                Toast.makeText(s_classroom_add.this, "ClassRoom Added Sucessfully", Toast.LENGTH_SHORT).show();


            }
        });

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(s_classroom_add.this, s_classroom_show.class));
            }
        });

        dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(s_classroom_add.this, staff_dashboard.class));
            }
        });
    }
}
