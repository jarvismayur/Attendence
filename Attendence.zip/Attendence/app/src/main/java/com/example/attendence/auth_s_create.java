package com.example.attendence;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import javax.xml.validation.Validator;

public class auth_s_create extends AppCompatActivity {
    public EditText user, pass;
    public Button create;
    public FirebaseAuth mAuth;
    public FirebaseDatabase database;
    public DatabaseReference reference;
    public String id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_s_create);
        user = findViewById(R.id.e1);
        pass = findViewById(R.id.e2);
        create = findViewById(R.id.but1);
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        String token = getIntent().getStringExtra("token");
        //confirm the Token via database



        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = user.getText().toString().trim();
                String password = pass.getText().toString().trim();
                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(auth_s_create.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            id = mAuth.getCurrentUser().getUid();
                            add();
                            Toast.makeText(auth_s_create.this, "Successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(auth_s_create.this, staff_login.class));
                        }else{
                            Toast.makeText(auth_s_create.this, "Try Again", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    private void add() {
        reference = database.getReference();
        reference = reference.child("Profile/Staff").child(id);
        reference.child("fname").setValue(getIntent().getStringExtra("fname"));
        reference.child("lname").setValue(getIntent().getStringExtra("lname"));
        reference.child("dob").setValue(getIntent().getStringExtra("dob"));
        reference.child("mob").setValue(getIntent().getStringExtra("mob"));
        reference.child("dept").setValue(getIntent().getStringExtra("dept"));
        reference.child("token").setValue(getIntent().getStringExtra("token"));


    }
}
