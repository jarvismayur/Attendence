package com.example.attendence;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class staff_create_account extends AppCompatActivity {
    public EditText fname, lname, dob, mob, dept, token;
    public Button next;
    private FirebaseAuth mAuth;
    public FirebaseDatabase database;
    public DatabaseReference reference;
    public String challan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_create_account);
        fname = findViewById(R.id.editText);
        lname = findViewById(R.id.editText2);
        dob = findViewById(R.id.editText3);
        mob = findViewById(R.id.editText4);
        dept = findViewById(R.id.editText5);
        token = findViewById(R.id.editText6);

        next =findViewById(R.id.but1);

        database = FirebaseDatabase.getInstance();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                challan  = token.getText().toString().trim();
                //check token form firebase database
                reference = database.getReference().child("Token").child(challan);
                reference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String data = dataSnapshot.getValue(String.class);
                        if (data == challan){
                            reference.removeValue();
                            Intent intent  = new Intent(staff_create_account.this, auth_s_create.class);
                            intent.putExtra("fname", fname.getText().toString().trim());
                            intent.putExtra("lname", lname.getText().toString().trim());
                            intent.putExtra("dob", dob.getText().toString().trim());
                            intent.putExtra("mob", mob.getText().toString().trim());
                            intent.putExtra("dept", dept.getText().toString().trim());
                            intent.putExtra("token", token.getText().toString().trim());
                            startActivity(intent);
                        }else{
                            Toast.makeText(staff_create_account.this, "Please Contact To Ur Administator For Token", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        });
    }
}
